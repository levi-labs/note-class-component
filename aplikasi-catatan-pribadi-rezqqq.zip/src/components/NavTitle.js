import React from 'react';

export default function NavTitle() {
  return (
    <>
      <nav>
        <div className='judul'>
          <a href='#'>
            <h2>Aplikasi Catatan</h2>
          </a>
        </div>
      </nav>
    </>
  );
}
