import React from 'react';

export default function NoteBody({ body }) {
  return <div className='card-body'>{body}</div>;
}
